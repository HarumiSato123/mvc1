﻿jQuery(document).ready(function (jq) {

    /*debugger*/
    /*alert(" Teste");*/
   
    
  
    var inputIE = jq("#inscricaoEstadual");
    inputIE.each(function () {
        jQuery(this).on("keypress", function () {
            console.log(this.value);
            if (mascaraInteiro(this.value) == false) {
                event.returnValue = false;
            }
            formataCampo(this, '00.000.000-0', event);
        });
        jQuery(this).on("blur", function () {
            if (mascaraInteiro(this.value) == false) {
                event.returnValue = false;
            }
            formataCampo(this, '00.000.000-0', event);
        });
    });
});

function formataCampo(campo, Mascara, evento) {
    var boleanoMascara;

    var Digitato = evento.keyCode;
    exp = /\-|\.|\/|\(|\)| /g;
    campoSoNumeros = campo.value.toString().replace(exp, "");

    var posicaoCampo = 0;
    var NovoValorCampo = "";
    var TamanhoMascara = campoSoNumeros.length;;

    if (Digitato != 8) { // backspace 
        for (i = 0; i <= TamanhoMascara; i++) {
            boleanoMascara = ((Mascara.charAt(i) == "-") || (Mascara.charAt(i) == ".")
                || (Mascara.charAt(i) == "/"));
            boleanoMascara = boleanoMascara || ((Mascara.charAt(i) == "(")
                || (Mascara.charAt(i) == ")") || (Mascara.charAt(i) == " "));
            if (boleanoMascara) {
                NovoValorCampo += Mascara.charAt(i);
                TamanhoMascara++;
            } else {
                NovoValorCampo += campoSoNumeros.charAt(posicaoCampo);
                posicaoCampo++;
            }
        }
        campo.value = NovoValorCampo;
        return true;
    } else {
        return true;
    }
}

function customNumeric(e, excecoes) {
    //var whichCode = (window.Event) ? e.which : e.keyCode;
    var whichCode = (e.which) ? e.which : event.keyCode;

    //Teclas funcionais permitidas.
    switch (whichCode) {
        case (8): return true; //Backspace
        case (9): return true; //Tab
        case (13): return true; //Enter
        case (16): return true; //Shift
        case (17): return true; //Ctrl
        case (35): return true; //End
        case (36): return true; //Home
        case (37): return true; //Seta esquerda
        case (39 && String.fromCharCode(39) != "'"): return true; //Seta direita, (aspas tem o mesmo númeric, por isso o if)
        case (46 && String.fromCharCode(46) != "."): return true; //Delete

        case (67): if (e.ctrlKey) return true; //Ctrl + C
        case (88): if (e.ctrlKey) return true; //Ctrl + X
        case (118): if (e.ctrlKey) return true; //Ctrl + V

        //Tratamento para as demais.
        default:
            key = String.fromCharCode(whichCode);

            var strCheck = "0123456789";

            if (excecoes) strCheck += excecoes;

            if (strCheck.indexOf(key) == -1) {
                return false;
            }

            return true;
    }
}


function mascaraInteiro() {
    console.log(event.keyCode);
    if (event.keyCode < 48 || event.keyCode > 57) {
        event.returnValue = false;
        return false;
    }
    return true;
}

